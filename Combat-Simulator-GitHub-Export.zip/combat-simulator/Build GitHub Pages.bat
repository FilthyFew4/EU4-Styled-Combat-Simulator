@echo off
setlocal
cd /d "%~dp0"

where npm.cmd >nul 2>nul
if errorlevel 1 (
  echo Node.js and npm were not found. Install Node.js 24 or later, then reopen this folder.
  pause
  exit /b 1
)

if not exist "node_modules\vite\bin\vite.js" (
  echo Installing the standalone simulator's dependencies...
  call npm.cmd install
  if errorlevel 1 (
    echo Setup failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)

call npm.cmd run build
if errorlevel 1 (
  echo The GitHub Pages build failed. Review the messages above and try again.
  pause
  exit /b 1
)

echo.
echo GitHub Pages files are ready in the docs folder.
pause
