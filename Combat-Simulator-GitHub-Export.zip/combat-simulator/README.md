# Combat Simulator

A standalone land and naval battle sandbox based on the combat simulator developed for Azgaar's Fantasy Map Generator. It runs independently and does not need the map generator.

## Run on Windows

1. Install Node.js 24 or later.
2. Double-click **Start Combat Simulator.bat**. On first run it installs this project's dependencies, then opens the simulator at `http://127.0.0.1:5180/`.
3. Keep the command window open while using the simulator. Close it to stop the local server.

You can also run `npm install` and `npm run start` from this folder.

## Build for GitHub Pages

Double-click **Build GitHub Pages.bat**, or run `npm install` followed by `npm run build`. The complete static site is written to `docs/`.

To publish from a separate GitHub repository, upload this folder's contents, then set **Settings → Pages → Deploy from a branch**, choose the `main` branch and `/docs` folder. The site uses relative asset paths, so it works at the repository's GitHub Pages address.

The simulator includes both land and naval combat, editable unit and ship values, setup import/export, battle formations, and round-by-round resolution. Its combat rules are an experimental tabletop-style model inspired by EU4, not a claim of exact game parity.

## License and attribution

This project is distributed under the MIT License. See [LICENSE](LICENSE) for the original copyright and license terms.
