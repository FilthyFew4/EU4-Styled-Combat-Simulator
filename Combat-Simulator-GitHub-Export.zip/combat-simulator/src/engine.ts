export type CombatRole = "frontline" | "backline" | "flanker";
export type CombatPhase = "fire" | "shock";
export type CombatSide = "attackers" | "defenders";
export type BattleTerrain = "plains" | "hills" | "forest" | "marsh" | "mountains";
export type Crossing = "none" | "river" | "strait";

export interface UnitDefinition {
  id: string;
  name: string;
  role: CombatRole;
  color?: string;
  baseMorale: number;
  flankingRange: number;
  power: number;
  fireAttack: number;
  fireDefense: number;
  shockAttack: number;
  shockDefense: number;
  moraleAttack: number;
  moraleDefense: number;
}

export interface GeneralStats {fire: number; shock: number; maneuver: number}

export interface Regiment {
  id: string;
  unitId: string;
  count: number;
  organization: number;
  morale: number;
  retreated?: boolean;
}

export interface FormationPlan {
  front: (string | null)[];
  back: (string | null)[];
  reserves: string[];
}

export interface Army {
  name: string;
  regiments: Regiment[];
  formation?: FormationPlan;
}

export interface CombatSettings {
  width: number;
  casualtyRate: number;
  regimentSize: number;
  terrain: BattleTerrain;
  crossing: Crossing;
  generals: Record<CombatSide, GeneralStats>;
}

export interface RoundResult {
  round: number;
  phase: CombatPhase;
  attackerPower: number;
  defenderPower: number;
  attackerLosses: number;
  defenderLosses: number;
  attackerMorale: number;
  defenderMorale: number;
  attackerFront: string[];
  defenderFront: string[];
  attackerFormation: Formation;
  defenderFormation: Formation;
  attackerDie: number;
  defenderDie: number;
}

export interface FormationSlot {
  regimentId: string;
  column: number;
  unitId: string;
  name: string;
  role: CombatRole;
  row: "front" | "back";
  color?: string;
  count: number;
  organization: number;
  morale: number;
  moraleMax: number;
  retreated: boolean;
}

export interface Formation {
  front: FormationSlot[];
  back: FormationSlot[];
  reserves: FormationSlot[];
}

export interface BattleResult {
  winner: string | null;
  reason: string;
  attackers: Army;
  defenders: Army;
  rounds: RoundResult[];
}

export interface BattleSession extends BattleResult {
  attackerMorale: number;
  defenderMorale: number;
  attackerFrontSlots: number;
  defenderFrontSlots: number;
  done: boolean;
}

export const DEFAULT_UNITS: UnitDefinition[] = [
  {id: "infantry", name: "Infantry", role: "frontline", color: "#71866d", baseMorale: 100, flankingRange: 1, power: 1, fireAttack: 1, fireDefense: 2, shockAttack: 2, shockDefense: 2, moraleAttack: 1, moraleDefense: 2},
  {id: "archers", name: "Archers", role: "backline", color: "#6686a2", baseMorale: 100, flankingRange: 1, power: 0.9, fireAttack: 3, fireDefense: 1, shockAttack: 0, shockDefense: 1, moraleAttack: 2, moraleDefense: 1},
  {id: "cavalry", name: "Cavalry", role: "flanker", color: "#b18d4f", baseMorale: 100, flankingRange: 2, power: 1.1, fireAttack: 0, fireDefense: 1, shockAttack: 4, shockDefense: 2, moraleAttack: 2, moraleDefense: 2},
  {id: "artillery", name: "Artillery", role: "backline", color: "#8b7898", baseMorale: 100, flankingRange: 2, power: 1, fireAttack: 2, fireDefense: 2, shockAttack: 0, shockDefense: 2, moraleAttack: 1, moraleDefense: 2}
];

type PlacedRegiment = {regiment: Regiment; unit: UnitDefinition; row: "front" | "back"; column: number};
type BattleLine = {front: PlacedRegiment[]; back: PlacedRegiment[]; reserves: PlacedRegiment[]};
type Hit = {attacker: PlacedRegiment; target: PlacedRegiment; effectiveRoll: number; moraleRoll: number; score: number};

function exposedFrontPenalty(unit: UnitDefinition): {roll: number; strength: number; damageTaken: number} {
  if (unit.role !== "backline") return {roll: 0, strength: 1, damageTaken: 1};
  return unit.id === "artillery"
    ? {roll: 2, strength: 0.5, damageTaken: 2}
    : {roll: 1, strength: 0.75, damageTaken: 1.25};
}

const terrainPenalties: Record<BattleTerrain, number> = {plains: 0, hills: 1, forest: 1, marsh: 1, mountains: 2};

function makePlaced(regiment: Regiment, unit: UnitDefinition, column: number): PlacedRegiment {
  return {regiment, unit, row: unit.role === "backline" ? "back" : "front", column};
}

function placeArmy(army: Army, units: UnitDefinition[], width: number): BattleLine {
  const formation = army.formation ?? {front: [], back: [], reserves: []};
  army.formation = formation;
  while (formation.front.length < width) formation.front.push(null);
  while (formation.back.length < width) formation.back.push(null);
  const definitions = new Map(units.map(unit => [unit.id, unit]));
  const regiments = new Map(army.regiments.map(regiment => [regiment.id, regiment]));
  const placed = (id: string | null): PlacedRegiment | null => {
    const regiment = id && regiments.get(id);
    const unit = regiment && definitions.get(regiment.unitId);
    return regiment && unit && regiment.count > 0 && !regiment.retreated ? makePlaced(regiment, unit, -1) : null;
  };
  const front: PlacedRegiment[] = [];
  const back: PlacedRegiment[] = [];
  const used = new Set<string>();
  for (let column = 0; column < width; column++) {
    const frontId = formation.front[column];
    const backId = formation.back[column];
    const frontline = placed(frontId);
    const backline = placed(backId);
    if (frontline) {
      front.push({...frontline, row: "front", column});
      used.add(frontId!);
      if (backline) {
        back.push({...backline, row: "back", column});
        used.add(backId!);
      }
    } else if (backline) {
      front.push({...backline, row: "front", column});
      used.add(backId!);
      formation.front[column] = backId!;
      formation.back[column] = null;
    } else {
      formation.front[column] = null;
      if (frontId && regiments.get(frontId)?.retreated) formation.front[column] = null;
    }
  }
  const reserves = army.regiments.flatMap(regiment => {
    const unit = definitions.get(regiment.unitId);
    return unit && regiment.count > 0 && !regiment.retreated && !used.has(regiment.id)
      ? [{...makePlaced(regiment, unit, -1), row: unit.role === "backline" ? "back" as const : "front" as const}]
      : [];
  });
  const activeIds = new Set([...front, ...back].map(item => item.regiment.id));
  formation.reserves = army.regiments.filter(regiment => regiment.count > 0 && !regiment.retreated && !activeIds.has(regiment.id)).map(regiment => regiment.id);
  return {front, back, reserves};
}

function supportPips(target: PlacedRegiment, opposingLine: BattleLine, phase: CombatPhase, morale: boolean): number {
  const artillery = opposingLine.back.find(item => item.column === target.column && item.unit.id === "artillery");
  if (!artillery) return 0;
  const pips = morale ? artillery.unit.moraleDefense : phase === "fire" ? artillery.unit.fireDefense : artillery.unit.shockDefense;
  return Math.floor(pips / 2);
}

function terrainPenalty(side: CombatSide, settings: CombatSettings): number {
  if (side !== "attackers") return 0;
  const attacker = settings.generals.attackers;
  const defender = settings.generals.defenders;
  const crossing = attacker.maneuver > defender.maneuver ? 0 : settings.crossing === "river" ? 1 : settings.crossing === "strait" ? 2 : 0;
  return terrainPenalties[settings.terrain] + crossing;
}

function calculateHits(line: BattleLine, opposingLine: BattleLine, phase: CombatPhase, die: number, side: CombatSide, settings: CombatSettings): {power: number; hits: Hit[]} {
  const hits: Hit[] = [];
  const ownGeneral = settings.generals[side];
  const opposingGeneral = settings.generals[side === "attackers" ? "defenders" : "attackers"];
  const generalRoll = phase === "fire" ? ownGeneral.fire - opposingGeneral.fire : ownGeneral.shock - opposingGeneral.shock;
  const penalty = terrainPenalty(side, settings);
  const attackPips = (unit: UnitDefinition) => phase === "fire" ? unit.fireAttack : unit.shockAttack;
  const defensePips = (unit: UnitDefinition) => phase === "fire" ? unit.fireDefense : unit.shockDefense;
  for (const row of ["front", "back"] as const) {
    for (const attacker of line[row]) {
      const candidates = opposingLine.front
        .map(target => ({target, distance: Math.abs(target.column - attacker.column)}))
        .filter(candidate => candidate.distance <= attacker.unit.flankingRange)
        .sort((a, b) => a.distance - b.distance || a.target.column - b.target.column);
      if (!candidates.length) continue;
      const target = (candidates.find(candidate => candidate.distance === 0) ?? candidates[0]).target;
      const exposure = row === "front" ? exposedFrontPenalty(attacker.unit) : {roll: 0, strength: 1, damageTaken: 1};
      const effectiveRoll = Math.max(0, Math.min(9, die + generalRoll + attackPips(attacker.unit) - defensePips(target.unit) - supportPips(target, opposingLine, phase, false) - penalty - exposure.roll));
      const moraleRoll = Math.max(0, Math.min(9, die + generalRoll + attacker.unit.moraleAttack - target.unit.moraleDefense - supportPips(target, opposingLine, phase, true) - penalty - exposure.roll));
      const rowMultiplier = row === "back" ? 0.5 : 1;
      const score = attacker.regiment.count * attacker.unit.power * (attacker.regiment.organization / 100) * (0.5 + effectiveRoll / 10) * rowMultiplier * exposure.strength;
      hits.push({attacker, target, effectiveRoll, moraleRoll, score});
    }
  }
  return {power: hits.reduce((sum, hit) => sum + hit.score, 0), hits};
}

function snapshotFormation(line: BattleLine): Formation {
  const snapshot = (items: PlacedRegiment[]): FormationSlot[] => items.map(({regiment, unit, column}) => ({
    regimentId: regiment.id, column, unitId: unit.id, name: unit.name, role: unit.role, row: items[0]?.row ?? "front", color: unit.color,
    count: regiment.count, organization: regiment.organization, morale: regiment.morale, moraleMax: unit.baseMorale,
    retreated: Boolean(regiment.retreated)
  }));
  return {front: snapshot(line.front), back: snapshot(line.back), reserves: snapshot(line.reserves)};
}

function applyHits(hits: Hit[], settings: CombatSettings, random: () => number): number {
  let losses = 0;
  const byTarget = new Map<string, Hit[]>();
  for (const hit of hits) byTarget.set(hit.target.regiment.id, [...(byTarget.get(hit.target.regiment.id) ?? []), hit]);
  for (const targetHits of byTarget.values()) {
    const target = targetHits[0].target;
    const score = targetHits.reduce((sum, hit) => sum + hit.score, 0);
    const strength = Math.max(1, target.regiment.count * target.unit.power * (target.regiment.organization / 100));
    const damageRate = Math.min(0.5, settings.casualtyRate * score / (score + strength));
    const targetExposure = target.row === "front" ? exposedFrontPenalty(target.unit) : {roll: 0, strength: 1, damageTaken: 1};
    const lost = Math.min(target.regiment.count, Math.floor(target.regiment.count * Math.min(0.75, damageRate * targetExposure.damageTaken) * (0.8 + random() * 0.4)));
    target.regiment.count -= lost;
    losses += lost;
    const moraleDamage = targetHits.reduce((sum, hit) => {
      const moraleFactor = (15 + 5 * hit.moraleRoll) / 50;
      const exposure = hit.attacker.row === "front" ? exposedFrontPenalty(hit.attacker.unit) : {roll: 0, strength: 1, damageTaken: 1};
      return sum + 5 * moraleFactor * (hit.attacker.regiment.count / settings.regimentSize) * hit.attacker.unit.power * (hit.attacker.regiment.organization / 100) * exposure.strength;
    }, 0) * targetExposure.damageTaken;
    target.regiment.morale = Math.max(0, target.regiment.morale - moraleDamage);
  }
  return losses;
}

function applyPassiveMoraleLoss(line: BattleLine, army: Army, units: UnitDefinition[], deployedRate: number, reserveRate: number): void {
  const unitById = new Map(units.map(unit => [unit.id, unit]));
  const deployed = new Set([...line.front, ...line.back].map(item => item.regiment.id));
  for (const regiment of army.regiments) {
    if (regiment.count <= 0 || regiment.retreated) continue;
    const unit = unitById.get(regiment.unitId);
    if (!unit) continue;
    const rate = deployed.has(regiment.id) ? deployedRate : reserveRate;
    regiment.morale = Math.max(0, regiment.morale - unit.baseMorale * rate);
  }
}

function retreatBrokenUnits(army: Army, line: BattleLine): void {
  const formation = army.formation;
  if (!formation) return;
  for (const [row, items] of [["front", line.front], ["back", line.back]] as const) {
    for (const item of items) {
      if (item.regiment.morale > 0 && item.regiment.count > 0) continue;
      item.regiment.retreated = true;
      formation[row][item.column] = null;
    }
  }
  for (const regiment of army.regiments) {
    if (regiment.count > 0 && !regiment.retreated && regiment.morale <= 0) regiment.retreated = true;
  }
  formation.reserves = army.regiments.filter(regiment => regiment.count > 0 && !regiment.retreated && !formation.front.includes(regiment.id) && !formation.back.includes(regiment.id)).map(regiment => regiment.id);
}

function reinforceFront(army: Army, units: UnitDefinition[], capacity: number): void {
  const formation = army.formation;
  if (!formation) return;
  const definitions = new Map(units.map(unit => [unit.id, unit]));
  let entered = 0;
  for (let column = 0; column < formation.front.length && entered < capacity; column++) {
    if (formation.front[column]) continue;
    const index = formation.reserves.findIndex(id => {
      const regiment = army.regiments.find(item => item.id === id);
      return regiment && regiment.count > 0 && !regiment.retreated && regiment.morale > 0 && definitions.get(regiment.unitId)?.role !== "backline";
    });
    if (index < 0) break;
    const [id] = formation.reserves.splice(index, 1);
    formation.front[column] = id;
    entered++;
  }
}

function reinforceBack(army: Army, units: UnitDefinition[], capacity: number): void {
  const formation = army.formation;
  if (!formation) return;
  const definitions = new Map(units.map(unit => [unit.id, unit]));
  let entered = 0;
  for (let column = 0; column < formation.back.length && entered < capacity; column++) {
    if (formation.back[column]) continue;
    const index = formation.reserves.findIndex(id => {
      const regiment = army.regiments.find(item => item.id === id);
      return regiment && regiment.count > 0 && !regiment.retreated && regiment.morale > 0 && definitions.get(regiment.unitId)?.role === "backline";
    });
    if (index < 0) break;
    const [id] = formation.reserves.splice(index, 1);
    formation.back[column] = id;
    entered++;
  }
}

function advanceBackline(army: Army): void {
  const formation = army.formation;
  if (!formation) return;
  const regiments = new Map(army.regiments.map(regiment => [regiment.id, regiment]));
  for (let column = 0; column < formation.front.length; column++) {
    if (formation.front[column]) continue;
    const id = formation.back[column];
    const regiment = id && regiments.get(id);
    if (!id || !regiment || regiment.count <= 0 || regiment.retreated || regiment.morale <= 0) continue;
    formation.front[column] = id;
    formation.back[column] = null;
  }
}

function armyMorale(army: Army, units: UnitDefinition[]): number {
  const definitions = new Map(units.map(unit => [unit.id, unit]));
  const active = army.regiments.filter(regiment => regiment.count > 0 && !regiment.retreated);
  const total = active.reduce((sum, regiment) => sum + regiment.count, 0);
  return total ? active.reduce((sum, regiment) => sum + regiment.count * regiment.morale / Math.max(1, definitions.get(regiment.unitId)?.baseMorale ?? 100), 0) / total * 100 : 0;
}

function reinforcementCapacity(maneuver: number): number {
  return 6 + Math.floor(maneuver / 2) * 3;
}

export function startBattle(attacker: Army, defender: Army, units: UnitDefinition[], settings: CombatSettings): BattleSession {
  const attackers = structuredClone(attacker);
  const defenders = structuredClone(defender);
  return {
    winner: null, reason: "Battle in progress", attackers, defenders, rounds: [],
    attackerMorale: armyMorale(attackers, units), defenderMorale: armyMorale(defenders, units),
    attackerFrontSlots: settings.width, defenderFrontSlots: settings.width, done: false
  };
}

export function resolveNextRound(session: BattleSession, units: UnitDefinition[], settings: CombatSettings, random: () => number = Math.random): RoundResult | null {
  if (session.done) return null;
  const round = session.rounds.length + 1;
  const phase: CombatPhase = round % 2 ? "fire" : "shock";
  const attackerLine = placeArmy(session.attackers, units, settings.width);
  const defenderLine = placeArmy(session.defenders, units, settings.width);
  const attackerDie = Math.floor(random() * 10);
  const defenderDie = Math.floor(random() * 10);
  const attackerFormation = snapshotFormation(attackerLine);
  const defenderFormation = snapshotFormation(defenderLine);
  const attackerHits = calculateHits(attackerLine, defenderLine, phase, attackerDie, "attackers", settings);
  const defenderHits = calculateHits(defenderLine, attackerLine, phase, defenderDie, "defenders", settings);
  const attackerPower = attackerHits.power;
  const defenderPower = defenderHits.power;
  if (!attackerPower || !defenderPower) {
    session.winner = attackerPower ? session.attackers.name : defenderPower ? session.defenders.name : null;
    session.reason = session.winner ? "Opposing army has no active line" : "Both armies have no active line";
    session.done = true;
    return null;
  }
  const attackerLosses = applyHits(defenderHits.hits, settings, random);
  const defenderLosses = applyHits(attackerHits.hits, settings, random);
  applyPassiveMoraleLoss(attackerLine, session.attackers, units, 0.03, 0.06);
  applyPassiveMoraleLoss(defenderLine, session.defenders, units, 0.03, 0.06);
  retreatBrokenUnits(session.attackers, attackerLine);
  retreatBrokenUnits(session.defenders, defenderLine);
  advanceBackline(session.attackers);
  advanceBackline(session.defenders);
  reinforceFront(session.attackers, units, reinforcementCapacity(settings.generals.attackers.maneuver));
  reinforceFront(session.defenders, units, reinforcementCapacity(settings.generals.defenders.maneuver));
  reinforceBack(session.attackers, units, reinforcementCapacity(settings.generals.attackers.maneuver));
  reinforceBack(session.defenders, units, reinforcementCapacity(settings.generals.defenders.maneuver));
  session.attackerMorale = armyMorale(session.attackers, units);
  session.defenderMorale = armyMorale(session.defenders, units);
  const result: RoundResult = {
    round, phase, attackerPower, defenderPower, attackerLosses, defenderLosses,
    attackerMorale: session.attackerMorale, defenderMorale: session.defenderMorale,
    attackerFront: attackerLine.front.map(item => item.unit.name), defenderFront: defenderLine.front.map(item => item.unit.name),
    attackerFormation, defenderFormation, attackerDie, defenderDie
  };
  session.rounds.push(result);
  const attackersRemain = session.attackers.regiments.some(regiment => regiment.count > 0 && !regiment.retreated);
  const defendersRemain = session.defenders.regiments.some(regiment => regiment.count > 0 && !regiment.retreated);
  const attackersBroken = !attackersRemain || !session.attackerMorale;
  const defendersBroken = !defendersRemain || !session.defenderMorale;
  if (attackersBroken || defendersBroken) {
    session.winner = attackersBroken === defendersBroken ? null : attackersBroken ? session.defenders.name : session.attackers.name;
    const brokenArmy = attackersBroken ? session.attackers : session.defenders;
    const brokenHasSurvivingRetreats = brokenArmy.regiments.some(regiment => regiment.retreated && regiment.count > 0);
    session.reason = attackersBroken && defendersBroken
      ? "Both armies broke from morale or losses"
      : brokenHasSurvivingRetreats
        ? `${brokenArmy.name} routed after morale collapsed`
        : `${brokenArmy.name} was destroyed`;
    session.done = true;
  }
  return result;
}

export function simulateBattle(attacker: Army, defender: Army, units: UnitDefinition[], settings: CombatSettings, random: () => number = Math.random): BattleResult {
  const session = startBattle(attacker, defender, units, settings);
  while (!session.done) resolveNextRound(session, units, settings, random);
  return {winner: session.winner, reason: session.reason, attackers: session.attackers, defenders: session.defenders, rounds: session.rounds};
}
