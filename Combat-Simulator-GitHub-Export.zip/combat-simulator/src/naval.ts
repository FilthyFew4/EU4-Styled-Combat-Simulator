import "./naval.css";

type Phase = "fire" | "shock";
type Side = "attackers" | "defenders";
type SeaZone = "ocean" | "coastal" | "inland";
type ShipType = {id: string; name: string; color: string; width: number; hull: number; cannons: number; fireAttack: number; fireDefense: number; shockAttack: number; shockDefense: number; moraleAttack: number; moraleDefense: number; baseMorale: number};
type Admiral = {fire: number; shock: number; maneuver: number};
type Ship = {id: string; typeId: string; hull: number; morale: number; state: "ready" | "disengaged" | "sunk"};
type Fleet = {name: string; ships: Ship[]};
type Turn = {number: number; phase: Phase; dice: [number, number]; losses: [number, number]; engaged: [string[], string[]]; totals: [number, number]; morale: [number, number]};
export type NavalSetup = {shipTypes: ShipType[]; fleets: Record<Side, {name: string; counts: Record<string, number>}>; seaZone: SeaZone; engagementWidth: number; admirals: Record<Side, Admiral>};
export type EmbeddedNavalCounts = Record<Side, Record<string, number>>;

const navalDefaults: ShipType[] = [
  {id: "heavy", name: "Heavy ship", color: "#6686a2", width: 3, hull: 100, cannons: 100, fireAttack: 3, fireDefense: 3, shockAttack: 1, shockDefense: 2, moraleAttack: 2, moraleDefense: 2, baseMorale: 100},
  {id: "galley", name: "Galley", color: "#b18d4f", width: 0.5, hull: 70, cannons: 60, fireAttack: 1, fireDefense: 1, shockAttack: 3, shockDefense: 2, moraleAttack: 1, moraleDefense: 2, baseMorale: 100},
  {id: "light", name: "Light ship", color: "#71866d", width: 1, hull: 60, cannons: 45, fireAttack: 2, fireDefense: 1, shockAttack: 1, shockDefense: 1, moraleAttack: 1, moraleDefense: 1, baseMorale: 100},
  {id: "transport", name: "Transport", color: "#8b7898", width: 1, hull: 50, cannons: 15, fireAttack: 0, fireDefense: 0, shockAttack: 0, shockDefense: 1, moraleAttack: 0, moraleDefense: 1, baseMorale: 100}
];

let shipTypes = navalDefaults.map(ship => ({...ship}));
let fleets: Record<Side, {name: string; counts: Record<string, number>}> = {
  attackers: {name: "Attacking fleet", counts: {heavy: 4, galley: 6, light: 4, transport: 2}},
  defenders: {name: "Defending fleet", counts: {heavy: 3, galley: 8, light: 3, transport: 2}}
};
let seaZone: SeaZone = "ocean";
let engagementWidth = 12;
let admirals: Record<Side, Admiral> = {attackers: {fire: 0, shock: 0, maneuver: 0}, defenders: {fire: 0, shock: 0, maneuver: 0}};
let battle: {fleets: Record<Side, Fleet>; turns: Turn[]; winner: string | null; reason: string; done: boolean} | null = null;
let embeddedMode = false;
let embeddedApply: ((counts: EmbeddedNavalCounts) => void) | null = null;

const esc = (value: string) => value.replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"})[c]!);
const totalShips = (fleet: Fleet) => fleet.ships.filter(ship => ship.state !== "sunk").length;
const fleetMorale = (fleet: Fleet) => {
  const living = fleet.ships.filter(ship => ship.state === "ready");
  return living.length ? Math.round(living.reduce((sum, ship) => sum + ship.morale, 0) / living.length) : 0;
};
const sunkShips = (fleet: Fleet) => fleet.ships.filter(ship => ship.state === "sunk").length;
const disengagedShips = (fleet: Fleet) => fleet.ships.filter(ship => ship.state === "disengaged").length;

export function renderNaval(root: HTMLElement, onLand: () => void, setup?: NavalSetup, onApply?: (counts: EmbeddedNavalCounts) => void): void {
  if (setup) {
    shipTypes = setup.shipTypes.map(ship => ({...ship}));
    fleets = structuredClone(setup.fleets);
    seaZone = setup.seaZone;
    engagementWidth = setup.engagementWidth;
    admirals = structuredClone(setup.admirals);
    battle = null;
    embeddedMode = true;
    embeddedApply = onApply ?? null;
  }
  root.classList.toggle("combat-embedded", embeddedMode);
  root.innerHTML = `<header class="topbar"><div class="header-title"><span class="eyebrow">LAND & NAVAL COMBAT</span><h1>Combat Simulator</h1></div><div class="header-actions"><label class="quiet naval-import">Import Setup<input id="navalImport" type="file" accept="application/json,.json" hidden></label><button id="navalExport" class="quiet">Export Setup</button></div></header>
    <nav class="mode-tabs"><button id="landMode" class="quiet">Land Combat</button><button class="active" aria-current="page">Naval Combat</button></nav>
    <section class="intro"><p>An EU4-inspired fleet model using the simulator's alternating Fire/Shock rounds, dice, editable pips, morale, and one-click resolution.</p></section>
    <section class="card naval-settings"><div><label>Engagement Width<input id="engagementWidth" type="number" min="1" max="100" value="${engagementWidth}"></label><small>Available ship width per side. Heavy ships use 3; galleys use 0.5.</small></div><div><label>Sea Zone<select id="seaZone"><option value="ocean" ${seaZone === "ocean" ? "selected" : ""}>Open ocean</option><option value="coastal" ${seaZone === "coastal" ? "selected" : ""}>Coastal waters</option><option value="inland" ${seaZone === "inland" ? "selected" : ""}>Inland sea</option></select></label><small>Inland seas double galley damage; coastal waters reduce width by 20%.</small></div></section>
    <section class="card naval-units"><div class="section-heading"><div><span class="eyebrow">EDITABLE BASE VALUES</span><h2>Ship Types</h2></div><button id="addShipType" class="quiet">+ Add Ship Type</button></div><p class="help">Ships are selected Heavy → Galley → Light → Transport until engagement width is filled. Fire/Shock pips affect attack rolls; hull and morale are separate.</p><div class="table-wrap"><table><thead><tr><th>Ship</th><th>Color</th><th>Width</th><th>Hull</th><th>Cannons</th><th>Fire A/D</th><th>Shock A/D</th><th>Morale A/D</th><th aria-label="Remove ship type"></th></tr></thead><tbody id="shipTypeRows"></tbody></table></div></section>
    <section id="navalFleets" class="naval-fleets">${renderFleetInputs("attackers", "Attacking Fleet")}${renderFleetInputs("defenders", "Defending Fleet")}</section>
    <section class="card admiral-card"><div class="section-heading"><div><span class="eyebrow">COMMAND</span><h2>Admirals</h2></div></div><div class="admiral-grid">${(["attackers", "defenders"] as Side[]).map(side => `<div class="general-side"><h3>${side === "attackers" ? "Attacking" : "Defending"} Admiral</h3><div class="general-stats">${(["fire", "shock", "maneuver"] as const).map(stat => `<label title="${stat === "fire" ? "Adds to Fire attack rolls." : stat === "shock" ? "Adds to Shock attack rolls." : "Increases this side's engagement width by 2 per pip."}">${stat[0].toUpperCase() + stat.slice(1)}<input type="number" min="0" max="6" data-admiral="${side}" data-stat="${stat}" value="${admirals[side][stat]}"></label>`).join("")}</div></div>`).join("")}</div></section>
    <div class="naval-actions"><button id="navalStart" class="primary">Resolve first round</button><button id="navalFast" class="quiet">Resolve battle</button></div>
    <section id="navalResults"></section><footer title="A ship attempts to disengage when its morale reaches 0.5 or lower. Sinking a ship causes morale loss across its fleet. Inland seas double galley damage. Transports have very low cannon values.">Ships disengage when morale reaches 0.5 or lower. A sunk ship lowers morale across its fleet. Galleys deal double damage in inland seas; transports are vulnerable in combat.</footer>`;
  root.querySelector<HTMLButtonElement>("#landMode")!.onclick = onLand;
  root.querySelector<HTMLElement>("#shipTypeRows")!.innerHTML = shipTypes.map(ship => `<tr data-shiptype="${ship.id}"><th><input data-value="name" aria-label="Ship type name" value="${esc(ship.name)}"></th><td><input data-value="color" type="color" aria-label="${esc(ship.name)} color" value="${ship.color}"></td><td><input data-value="width" type="number" min="0.5" step="0.5" value="${ship.width}"></td><td><input data-value="hull" type="number" min="1" value="${ship.hull}"></td><td><input data-value="cannons" type="number" min="0" value="${ship.cannons}"></td><td><input data-pips="fireAttack" type="number" min="0" max="6" value="${ship.fireAttack}">/<input data-pips="fireDefense" type="number" min="0" max="6" value="${ship.fireDefense}"></td><td><input data-pips="shockAttack" type="number" min="0" max="6" value="${ship.shockAttack}">/<input data-pips="shockDefense" type="number" min="0" max="6" value="${ship.shockDefense}"></td><td><input data-pips="moraleAttack" type="number" min="0" max="6" value="${ship.moraleAttack}">/<input data-pips="moraleDefense" type="number" min="0" max="6" value="${ship.moraleDefense}"></td><td><button class="remove-ship-type quiet" data-shiptype="${ship.id}" aria-label="Remove ${esc(ship.name)} ship type" title="Remove ship type">−</button></td></tr>`).join("");
  root.querySelectorAll<HTMLInputElement>("#shipTypeRows input").forEach(input => input.addEventListener("change", readInputs));
  root.querySelectorAll<HTMLButtonElement>(".remove-ship-type").forEach(button => button.onclick = () => {
    readInputs();
    const id = button.dataset.shiptype!;
    shipTypes = shipTypes.filter(ship => ship.id !== id);
    for (const side of ["attackers", "defenders"] as Side[]) delete fleets[side].counts[id];
    renderNaval(root, onLand);
  });
  root.querySelectorAll<HTMLInputElement>("#navalFleets input, .admiral-card input").forEach(input => input.addEventListener("change", readInputs));
  root.querySelector<HTMLButtonElement>("#addShipType")!.onclick = () => {
    readInputs();
    const id = `custom-${Date.now()}`;
    shipTypes.push({id, name: "Custom ship", color: "#71866d", width: 1, hull: 70, cannons: 50, fireAttack: 1, fireDefense: 1, shockAttack: 1, shockDefense: 1, moraleAttack: 1, moraleDefense: 1, baseMorale: 100});
    for (const side of ["attackers", "defenders"] as Side[]) fleets[side].counts[id] = 0;
    renderNaval(root, onLand);
    const addedRow = root.querySelector<HTMLTableRowElement>(`#shipTypeRows tr[data-shiptype="${id}"]`);
    addedRow?.scrollIntoView({behavior: "smooth", block: "nearest"});
    addedRow?.querySelector<HTMLInputElement>('[data-value="name"]')?.focus();
  };
  root.querySelector<HTMLInputElement>("#engagementWidth")!.onchange = readInputs;
  root.querySelector<HTMLSelectElement>("#seaZone")!.onchange = readInputs;
  root.querySelector<HTMLButtonElement>("#navalStart")!.onclick = () => advance(root, false);
  root.querySelector<HTMLButtonElement>("#navalFast")!.onclick = () => advance(root, true);
  root.querySelector<HTMLButtonElement>("#navalExport")!.onclick = () => {
    readInputs();
    const blob = new Blob([JSON.stringify({shipTypes, fleets, seaZone, engagementWidth, admirals}, null, 2)], {type: "application/json"});
    const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = "naval-combat-setup.json"; link.click(); URL.revokeObjectURL(link.href);
  };
  root.querySelector<HTMLInputElement>("#navalImport")!.onchange = async event => {
    const file = (event.target as HTMLInputElement).files?.[0]; if (!file) return;
    try { const data = JSON.parse(await file.text()); if (!Array.isArray(data.shipTypes) || !data.fleets) throw new Error("Not a naval combat setup file."); shipTypes = data.shipTypes; fleets = data.fleets; seaZone = data.seaZone || "ocean"; engagementWidth = data.engagementWidth || 12; admirals = data.admirals || admirals; battle = null; renderNaval(root, onLand); }
    catch (error) { alert(error instanceof Error ? error.message : "Could not import setup."); }
  };
}

function renderFleetInputs(side: Side, title: string): string {
  const rows = shipTypes.map(ship => `<tr><td><span class="ship-color" style="--ship-color:${ship.color}"></span>${esc(ship.name)}</td><td><input data-fleet="${side}" data-ship="${ship.id}" type="number" min="0" max="500" value="${fleets[side].counts[ship.id] || 0}" ${embeddedMode ? "disabled" : ""}></td></tr>`).join("");
  return `<section class="card fleet-card ${side}"><div class="section-heading"><div><span class="eyebrow">${side === "attackers" ? "FLEET A" : "FLEET B"}</span><h2>${title}</h2></div></div><label class="army-name">Fleet name<input data-fleet-name="${side}" value="${esc(fleets[side].name)}" ${embeddedMode ? "disabled" : ""}></label><table><thead><tr><th>Ship type</th><th>Ships</th></tr></thead><tbody>${rows}</tbody></table></section>`;
}

function readInputs(): void {
  const root = document.querySelector<HTMLElement>("#combat-sandbox")!;
  engagementWidth = Math.max(1, +root.querySelector<HTMLInputElement>("#engagementWidth")!.value || 12);
  seaZone = root.querySelector<HTMLSelectElement>("#seaZone")!.value as SeaZone;
  root.querySelectorAll<HTMLTableRowElement>("#shipTypeRows tr").forEach(row => {
    const ship = shipTypes.find(item => item.id === row.dataset.shiptype)!;
    row.querySelectorAll<HTMLInputElement>("input").forEach(input => {
      const key = input.dataset.value as "name" | "color" | "width" | "hull" | "cannons" | undefined;
      if (key === "name") ship.name = input.value.trim() || "Unnamed ship";
      else if (key === "color") ship.color = input.value;
      else if (key) ship[key] = Math.max(key === "width" ? 0.5 : 0, +input.value || 0);
      const pip = input.dataset.pips as keyof ShipType | undefined;
      if (pip) (ship[pip] as number) = Math.max(0, Math.min(6, Math.round(+input.value || 0)));
    });
  });
  root.querySelectorAll<HTMLInputElement>("#navalFleets input").forEach(input => {
    const side = input.dataset.fleet as Side | undefined;
    if (side && input.dataset.ship) fleets[side].counts[input.dataset.ship] = Math.max(0, Math.min(embeddedMode ? 100000 : 500, Math.floor(+input.value || 0)));
    if (input.dataset.fleetName) fleets[input.dataset.fleetName as Side].name = input.value.trim() || "Fleet";
  });
  root.querySelectorAll<HTMLInputElement>(".admiral-card input").forEach(input => {admirals[input.dataset.admiral as Side][input.dataset.stat as keyof Admiral] = Math.max(0, Math.min(6, Math.round(+input.value || 0)));});
}

function makeFleet(side: Side): Fleet {
  return {name: fleets[side].name, ships: shipTypes.flatMap(type => Array.from({length: fleets[side].counts[type.id] || 0}, (_, index) => ({id: `${side}-${type.id}-${index + 1}`, typeId: type.id, hull: 100, morale: type.baseMorale, state: "ready" as const})))};
}

function engagedShips(fleet: Fleet, admiral: Admiral): Ship[] {
  const width = engagementWidth * (seaZone === "coastal" ? 0.8 : 1) + admiral.maneuver * 2;
  let used = 0;
  const priority = (ship: Ship) => {
    const type = shipTypes.find(item => item.id === ship.typeId);
    const name = `${ship.typeId} ${type?.name ?? ""}`.toLowerCase();
    return name.includes("heavy") ? 0 : name.includes("galley") ? 1 : name.includes("light") ? 2 : name.includes("transport") ? 3 : 4;
  };
  return fleet.ships.filter(ship => ship.state === "ready").sort((a, b) => priority(a) - priority(b)).filter(ship => {
    const type = shipTypes.find(item => item.id === ship.typeId)!;
    if (used + type.width > width) return false;
    used += type.width;
    return true;
  });
}

function advance(root: HTMLElement, fast: boolean): void {
  readInputs();
  if (!battle) battle = {fleets: {attackers: makeFleet("attackers"), defenders: makeFleet("defenders")}, turns: [], winner: null, reason: "Battle in progress", done: false};
  root.querySelectorAll<HTMLInputElement | HTMLSelectElement>(".naval-settings input, .naval-settings select, #shipTypeRows input, #navalFleets input, .admiral-card input").forEach(input => {input.disabled = true;});
  root.querySelectorAll<HTMLButtonElement>(".remove-ship-type").forEach(button => {button.disabled = true;});
  root.querySelector<HTMLButtonElement>("#addShipType")!.disabled = true;
  const importSetup = root.querySelector<HTMLElement>(".naval-import")!;
  importSetup.style.pointerEvents = "none";
  importSetup.style.opacity = "0.5";
  root.querySelector<HTMLButtonElement>("#navalStart")!.hidden = true;
  root.querySelector<HTMLButtonElement>("#navalFast")!.hidden = true;
  do {resolveTurn();} while (fast && !battle.done);
  renderNavalResults(root);
}

function resolveTurn(): void {
  if (!battle || battle.done) return;
  const number = battle.turns.length + 1;
  const phase: Phase = number % 2 ? "fire" : "shock";
  const dice: [number, number] = [Math.floor(Math.random() * 10), Math.floor(Math.random() * 10)];
  const engaged: [Ship[], Ship[]] = [engagedShips(battle.fleets.attackers, admirals.attackers), engagedShips(battle.fleets.defenders, admirals.defenders)];
  if (!engaged[0].length || !engaged[1].length) {
    const winIndex = engaged[0].length ? 0 : engaged[1].length ? 1 : -1;
    battle.winner = winIndex < 0 ? null : battle.fleets[winIndex === 0 ? "attackers" : "defenders"].name;
    battle.reason = winIndex < 0 ? "Neither fleet has ready ships able to engage" : "Opposing fleet has no ships able to engage";
    battle.done = true; return;
  }
  const before = [battle.fleets.attackers, battle.fleets.defenders] as const;
  const sunkBySide: [number, number] = [0, 0];
  const damage = new Map<string, {hull: number; morale: number}>();
  for (const sideIndex of [0, 1] as const) {
    const side: Side = sideIndex === 0 ? "attackers" : "defenders";
    const enemySide: Side = sideIndex === 0 ? "defenders" : "attackers";
    const ownGeneral = admirals[side]; const enemyGeneral = admirals[enemySide];
    const modifier = (phase === "fire" ? ownGeneral.fire - enemyGeneral.fire : ownGeneral.shock - enemyGeneral.shock);
    for (const attacker of engaged[sideIndex]) {
      const attackerType = shipTypes.find(type => type.id === attacker.typeId)!;
      const targets = engaged[sideIndex === 0 ? 1 : 0].filter(ship => ship.state === "ready");
      if (!targets.length) continue;
      const target = targets[Math.floor(Math.random() * targets.length)];
      const targetType = shipTypes.find(type => type.id === target.typeId)!;
      const atk = phase === "fire" ? attackerType.fireAttack : attackerType.shockAttack;
      const def = phase === "fire" ? targetType.fireDefense : targetType.shockDefense;
      const roll = Math.max(0, Math.min(9, dice[sideIndex] + modifier + atk - def));
      const galley = `${attacker.typeId} ${attackerType.name}`.toLowerCase().includes("galley");
      const galleyBonus = seaZone === "inland" && galley ? 2 : 1;
      const hullDamage = Math.max(0.5, (2 + roll) * 0.7 * attackerType.cannons / Math.max(1, targetType.hull) * galleyBonus);
      const moralePips = attackerType.moraleAttack - targetType.moraleDefense;
      const moraleDamage = Math.max(0.5, 1.5 + roll * 0.3 + moralePips + modifier * 0.5);
      const old = damage.get(target.id) || {hull: 0, morale: 0};
      old.hull += hullDamage; old.morale += moraleDamage; damage.set(target.id, old);
    }
  }
  const lost: [number, number] = [0, 0];
  for (const sideIndex of [0, 1] as const) {
    const fleet = before[sideIndex];
    let sinkShock = 0;
    for (const ship of fleet.ships) {
      const hit = damage.get(ship.id);
      if (hit && ship.state === "ready") {
        ship.hull = Math.max(0, ship.hull - hit.hull);
        ship.morale = Math.max(0, ship.morale - hit.morale);
        if (ship.hull <= 0) {ship.state = "sunk"; lost[sideIndex]++; sunkBySide[sideIndex]++; sinkShock += 2;}
        else if (ship.morale <= 0.5) ship.state = "disengaged";
      }
    }
    if (sinkShock) for (const ship of fleet.ships) if (ship.state === "ready" || ship.state === "disengaged") ship.morale = Math.max(0, ship.morale - sinkShock);
  }
  const turn: Turn = {
    number, phase, dice, losses: lost,
    engaged: [engaged[0].map(ship => ship.id), engaged[1].map(ship => ship.id)],
    totals: [totalShips(before[0]), totalShips(before[1])], morale: [fleetMorale(before[0]), fleetMorale(before[1])]
  };
  battle.turns.push(turn);
  const alive: [number, number] = [before[0].ships.filter(ship => ship.state === "ready").length, before[1].ships.filter(ship => ship.state === "ready").length];
  if (!alive[0] || !alive[1]) {
    battle.winner = alive[0] === alive[1] ? null : alive[0] ? before[0].name : before[1].name;
    const disengaged: [number, number] = [disengagedShips(before[0]), disengagedShips(before[1])];
    battle.reason = !alive[0] && !alive[1] ? "Both fleets were sunk or disengaged" : disengaged[0] + disengaged[1] > 0 ? "Fleet morale broke; surviving ships disengaged" : "Fleet destroyed";
    battle.done = true;
  }
}

function renderNavalResults(root: HTMLElement): void {
  if (!battle) return;
  const actions = battle.done
    ? embeddedMode ? `<button id="navalApply" class="primary">Apply result to map</button>` : `<button id="navalReset" class="quiet">Prepare another battle</button>`
    : `<button id="navalNext" class="primary">Resolve next round</button><button id="navalFastAgain" class="quiet">Resolve battle</button>${embeddedMode ? `<button id="navalApply" class="quiet">End battle and apply current losses</button>` : ""}`;
  const total = (side: Side) => totalShips(battle!.fleets[side]);
  const sunk = (side: Side) => sunkShips(battle!.fleets[side]);
  const disengaged = (side: Side) => disengagedShips(battle!.fleets[side]);
  const morale = (side: Side) => fleetMorale(battle!.fleets[side]);
  const result = `<section class="result-summary"><span class="eyebrow">${battle.done ? "BATTLE RESULT" : "CURRENT BATTLE"}</span><h2>${battle.winner ? `${esc(battle.winner)} wins` : battle.done ? "No clear winner" : "Naval battle in progress"}</h2><p>${esc(battle.reason)} · ${battle.turns.length} rounds</p><div class="naval-actions">${actions}</div></section><div class="naval-summary"><span>${esc(battle.fleets.attackers.name)} · ${total("attackers")} afloat · ${sunk("attackers")} sunk · ${disengaged("attackers")} disengaged · ${morale("attackers")}% morale</span><span>${esc(battle.fleets.defenders.name)} · ${total("defenders")} afloat · ${sunk("defenders")} sunk · ${disengaged("defenders")} disengaged · ${morale("defenders")}% morale</span></div>${battle.turns.slice().reverse().map(turn => `<details class="round-card"><summary>Round ${turn.number} · <span class="phase ${turn.phase}">${turn.phase}</span> · dice ${turn.dice.join("–")} · ships sunk ${turn.losses.join("–")}</summary><p class="naval-round-info">Engaged: ${turn.engaged.map(items => items.length).join(" vs ")} ships · Fleet morale ${turn.morale.join("% vs ")}%</p></details>`).join("")}`;
  root.querySelector<HTMLElement>("#navalResults")!.innerHTML = result;
  root.querySelector<HTMLButtonElement>("#navalNext")?.addEventListener("click", () => advance(root, false));
  root.querySelector<HTMLButtonElement>("#navalFastAgain")?.addEventListener("click", () => advance(root, true));
  root.querySelector<HTMLButtonElement>("#navalReset")?.addEventListener("click", () => {battle = null; renderNaval(root, () => document.querySelector<HTMLButtonElement>("#landMode")?.click());});
  root.querySelector<HTMLButtonElement>("#navalApply")?.addEventListener("click", () => {
    if (!battle || !embeddedApply) return;
    const counts = Object.fromEntries((["attackers", "defenders"] as Side[]).map(side => [side, Object.fromEntries(shipTypes.map(type => [type.id, battle!.fleets[side].ships.filter(ship => ship.typeId === type.id && ship.state !== "sunk").length]))])) as Record<Side, Record<string, number>>;
    embeddedApply(counts);
  });
}
