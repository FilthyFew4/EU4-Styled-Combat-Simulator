﻿import {DEFAULT_UNITS, resolveNextRound, startBattle, type Army, type BattleSession, type CombatRole, type CombatSettings, type Formation, type FormationPlan, type FormationSlot, type RoundResult, type UnitDefinition} from "./engine";
import "./styles.css";
import {renderNaval} from "./naval";

type SideKey = "attackers" | "defenders";
type Setup = {
  units: UnitDefinition[];
  settings: CombatSettings;
  armies: Record<SideKey, {name: string; counts: Record<string, number>; organization: Record<string, number>; formation?: FormationPlan}>;
};
const embedded = new URLSearchParams(location.search).get("embedded") === "1";
const postTarget = location.origin === "null" ? "*" : location.origin;
let preparedArmies: Record<SideKey, Army> | null = null;
let activeBattle: BattleSession | null = null;
let selectedBrigade: {side: SideKey; id: string} | null = null;

const root = document.querySelector<HTMLElement>("#combat-sandbox")!;
let setup: Setup = {
  units: DEFAULT_UNITS.map(unit => ({...unit})),
  settings: {width: 6, casualtyRate: 0.12, regimentSize: 500, terrain: "plains", crossing: "none", generals: {attackers: {fire: 0, shock: 0, maneuver: 0}, defenders: {fire: 0, shock: 0, maneuver: 0}}},
  armies: {
    attackers: {name: "Attackers", counts: {infantry: 1000, archers: 500, cavalry: 300, artillery: 200}, organization: {}},
    defenders: {name: "Defenders", counts: {infantry: 1100, archers: 300, cavalry: 200, artillery: 150}, organization: {}}
  }
};

for (const side of ["attackers", "defenders"] as const) {
  for (const unit of setup.units) setup.armies[side].organization[unit.id] = 100;
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, char => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"})[char]!);
}

function render(): void {
  document.body.classList.toggle("combat-embedded", embedded);
  root.innerHTML = `
    ${embedded ? "" : `<header class="topbar">
      <div class="header-title"><span class="eyebrow">LAND & NAVAL COMBAT</span><h1>Combat Simulator</h1></div>
      <div class="header-actions"><button id="importSetup" class="quiet">Import Setup</button><input id="setupFile" type="file" accept="application/json,.json" hidden><button id="exportSetup" class="quiet">Export Setup</button></div>
    </header>`}
    ${embedded ? "" : `<nav class="mode-tabs"><button class="active" aria-current="page">Land Combat</button><button id="navalMode" class="quiet">Naval Combat</button></nav>`}
    ${embedded ? "" : `<section class="intro"><p>A small, independent battle model for trying out Fire and Shock, frontage, flanking, and supply readiness before connecting anything to the map.</p></section>`}
    <section class="settings card">
      <div><label for="width">Combat Width</label><input id="width" type="number" min="1" max="20" step="1" value="${setup.settings.width}"><small>Slots per battle row</small></div>
      <div><label for="casualtyRate">Casualty Rate</label><input id="casualtyRate" type="number" min="0" max="1" step="0.01" value="${setup.settings.casualtyRate}"><small>Base losses each round</small></div>
      <button id="prepareBattle" class="primary">Set formations</button>
    </section>
    <section class="card command-card"><div class="section-heading"><div><span class="eyebrow">BATTLEFIELD & COMMAND</span><h2>Terrain and Generals</h2></div></div>
      <div class="terrain-fields"><label title="Hills, forest, marsh, and mountains reduce the attacker's combat roll.">Terrain<select id="terrain" title="Terrain penalties apply to the attacking side.">${(["plains", "hills", "forest", "marsh", "mountains"] as const).map(value => `<option value="${value}" ${setup.settings.terrain === value ? "selected" : ""}>${value[0].toUpperCase() + value.slice(1)}</option>`).join("")}</select></label>
      <label title="Rivers penalize the attacker by 1; straits by 2. Higher attacker Maneuver cancels this penalty.">Crossing<select id="crossing" title="Rivers penalize the attacker by 1; straits by 2. Higher attacker Maneuver cancels this penalty.">${(["none", "river", "strait"] as const).map(value => `<option value="${value}" ${setup.settings.crossing === value ? "selected" : ""}>${value === "none" ? "None" : value[0].toUpperCase() + value.slice(1)}</option>`).join("")}</select></label><small>Terrain and crossing penalties apply to attackers. Higher attacker Maneuver cancels crossing penalties.</small></div>
      <div class="general-grid">${(["attackers", "defenders"] as const).map(side => `<div class="general-side"><h3>${side === "attackers" ? "Attacking" : "Defending"} general</h3><div class="general-stats">${(["fire", "shock", "maneuver"] as const).map(stat => `<label title="${stat === "fire" ? "Added to this side's Fire phase roll." : stat === "shock" ? "Added to this side's Shock phase roll." : "Improves reserve arrivals: 6 plus 3 per 2 Maneuver pips each round."}">${stat[0].toUpperCase() + stat.slice(1)}<input title="${stat === "fire" ? "Added to Fire phase rolls." : stat === "shock" ? "Added to Shock phase rolls." : "Improves reserve arrivals."}" data-general="${side}" data-stat="${stat}" type="number" min="0" max="6" step="1" value="${setup.settings.generals[side][stat]}"></label>`).join("")}</div></div>`).join("")}</div>
    </section>
    ${embedded ? `<div class="embedded-size card"><label for="regimentSize">Max troops per brigade</label><input id="regimentSize" type="number" min="1" max="10000" step="50" value="${setup.settings.regimentSize}"></div>` : `<section class="card units-card">
      <div class="section-heading"><div><span class="eyebrow">EDITABLE BASE VALUES</span><h2>Unit Types</h2></div><div class="unit-tools"><label for="regimentSize" title="Troops are split into battle blocks no larger than this value.">Regiment Size<input id="regimentSize" title="Troops are split into battle blocks no larger than this value." type="number" min="1" max="10000" step="50" value="${setup.settings.regimentSize}"><small>Maximum troops per block</small></label><button id="addUnit" class="quiet">+ Add Unit</button></div></div>
      <p class="help">Base power multiplies strength. Fire/Shock pips affect troop damage; Morale pips affect morale damage. Flanking range sets how far a unit can reach sideways. Archers fight less effectively in the frontline; artillery is much weaker and takes more casualties there.</p>
      <div class="table-wrap"><table><thead><tr><th>Unit</th><th>Color</th><th title="Maximum morale for this unit.">Max morale</th><th title="Multiplies a unit's strength contribution.">Base power</th><th title="Maximum number of columns away this unit can target along the frontline.">Flank</th><th title="Added to attack rolls during Fire phases.">Fire ATK</th><th title="Reduces enemy Fire attack rolls.">Fire DEF</th><th title="Added to attack rolls during Shock phases.">Shock ATK</th><th title="Reduces enemy Shock attack rolls.">Shock DEF</th><th title="Added to morale damage rolls.">Morale ATK</th><th title="Reduces enemy morale damage rolls.">Morale DEF</th><th></th></tr></thead><tbody id="unitRows"></tbody></table></div>
    </section>`}
    <section class="armies ${embedded ? "embedded-armies" : ""}">
      ${renderArmy("attackers", "Attacking Army", "red")}
      ${renderArmy("defenders", "Defending Army", "blue")}
    </section>
    <section id="deployment" class="card deployment-card" hidden>
      <div class="section-heading"><div><span class="eyebrow">DEPLOYMENT</span><h2>Arrange the brigades</h2></div><div class="battle-actions"><button id="startBattle" class="primary" title="Resolve one Fire or Shock phase.">Resolve first round</button><button id="resolveUntilSurrender" class="quiet" title="Automatically resolve rounds until one army breaks or is destroyed.">Resolve battle</button></div></div>
      <p id="deployHelp" class="help">Each block holds at most ${setup.settings.regimentSize} troops. Infantry starts near the center, cavalry on the flanks. Backline units advance only into an empty frontline tile in their column.</p>
      <div id="deploymentArmies" class="deployment-armies"></div>
    </section>
    <section id="results" class="results"></section>
    <footer title="Morale: deployed units lose 3% of maximum morale each phase; reserves lose 6%. A unit that reaches zero morale retreats for good. Reinforcements: Maneuver adds 3 arrivals per 2 pips each phase. Artillery: half its defensive Fire, Shock, and Morale pips support the friendly frontline unit directly ahead.">One click resolves one three-day phase. Deployed units lose 3% and reserves 6% of maximum morale each phase. Low morale units retreat permanently; Maneuver controls reserve arrivals. Artillery passes half its defensive pips to the front unit directly ahead.</footer>`;

  const unitRows = root.querySelector<HTMLElement>("#unitRows");
  if (unitRows) unitRows.innerHTML = setup.units.map((unit, index) => `
    <tr data-unit="${escapeHtml(unit.id)}"><td><input class="unit-name" value="${escapeHtml(unit.name)}" aria-label="Unit name"></td>
    <td><input class="unit-color" type="color" value="${unit.color || defaultColor(unit.role)}" aria-label="${escapeHtml(unit.name)} color"></td>
    <td><input class="unit-morale" type="number" min="1" max="300" step="1" value="${unit.baseMorale}" aria-label="${escapeHtml(unit.name)} maximum morale" title="This is the unit's starting and maximum morale."></td>
    <td><input class="unit-power" type="number" min="0" step="0.05" value="${unit.power}" aria-label="Base power"></td>
    <td><input class="unit-flanking" type="number" min="0" max="6" step="1" value="${unit.flankingRange}" aria-label="Flanking range" title="Maximum number of columns away this unit can target along the enemy frontline."></td>
    <td><input class="fire-attack" type="number" min="0" max="6" step="1" value="${unit.fireAttack}" aria-label="Fire attack pips"></td>
    <td><input class="fire-defense" type="number" min="0" max="6" step="1" value="${unit.fireDefense}" aria-label="Fire defense pips"></td>
    <td><input class="shock-attack" type="number" min="0" max="6" step="1" value="${unit.shockAttack}" aria-label="Shock attack pips"></td>
    <td><input class="shock-defense" type="number" min="0" max="6" step="1" value="${unit.shockDefense}" aria-label="Shock defense pips"></td>
    <td><input class="morale-attack" type="number" min="0" max="6" step="1" value="${unit.moraleAttack}" aria-label="Morale attack pips" title="Helps reduce enemy morale when this unit attacks."></td>
    <td><input class="morale-defense" type="number" min="0" max="6" step="1" value="${unit.moraleDefense}" aria-label="Morale defense pips" title="Reduces morale damage this unit takes."></td>
    <td><button class="remove-unit quiet" data-index="${index}" aria-label="Remove unit">-</button></td></tr>`).join("");

  root.querySelector("#addUnit")?.addEventListener("click", () => {
    readControls();
    const id = `custom-${Date.now()}`;
    setup.units.push({id, name: "Custom unit", role: "frontline", color: "#71866d", baseMorale: 100, flankingRange: 1, power: 1, fireAttack: 1, fireDefense: 1, shockAttack: 1, shockDefense: 1, moraleAttack: 1, moraleDefense: 1});
    for (const side of ["attackers", "defenders"] as const) {
      setup.armies[side].counts[id] = 0;
      setup.armies[side].organization[id] = 100;
    }
    render();
  });
  root.querySelectorAll<HTMLButtonElement>(".remove-unit").forEach(button => button.addEventListener("click", () => {
    readControls();
    const [removed] = setup.units.splice(+button.dataset.index!, 1);
    for (const side of ["attackers", "defenders"] as const) {
      delete setup.armies[side].counts[removed.id];
      delete setup.armies[side].organization[removed.id];
    }
    render();
  }));
  root.querySelector("#prepareBattle")!.addEventListener("click", prepareBattle);
  root.querySelector<HTMLButtonElement>("#navalMode")?.addEventListener("click", () => renderNaval(root, render));
  root.querySelector<HTMLButtonElement>("#resolveUntilSurrender")!.addEventListener("click", runUntilSurrender);
  root.querySelector("#exportSetup")?.addEventListener("click", exportSetup);
  root.querySelector("#importSetup")?.addEventListener("click", () => root.querySelector<HTMLInputElement>("#setupFile")!.click());
  root.querySelector<HTMLInputElement>("#setupFile")?.addEventListener("change", importSetup);
}

function renderArmy(side: SideKey, title: string, color: string): string {
  const army = setup.armies[side];
  const rows = setup.units.map(unit => `
    <tr><td>${escapeHtml(unit.name)}</td><td><input data-count="${escapeHtml(unit.id)}" type="number" min="0" step="1" value="${army.counts[unit.id] || 0}" aria-label="${escapeHtml(unit.name)} count" ${embedded ? "disabled" : ""}></td>
    <td><input data-org="${escapeHtml(unit.id)}" type="number" min="0" max="100" step="1" value="${army.organization[unit.id] ?? 100}" aria-label="${escapeHtml(unit.name)} organization" ${embedded ? "disabled" : ""}></td></tr>`).join("");
  return `<section class="card army-card ${color}"><div class="section-heading"><div><span class="eyebrow">${side === "attackers" ? "SIDE A" : "SIDE B"}</span><h2>${title}</h2></div></div>
    <label class="army-name">Army name<input data-army="${side}" value="${escapeHtml(army.name)}" ${embedded ? "disabled" : ""}></label>
    <div class="table-wrap"><table><thead><tr><th>Unit regiment</th><th>Troops</th><th>Organization</th></tr></thead><tbody>${rows}</tbody></table></div></section>`;
}

function readControls(): void {
  setup.settings.width = Math.max(1, +root.querySelector<HTMLInputElement>("#width")!.value || 1);
  setup.settings.casualtyRate = Math.max(0, Math.min(1, +root.querySelector<HTMLInputElement>("#casualtyRate")!.value || 0));
  setup.settings.regimentSize = Math.max(1, Math.min(10000, Math.floor(+root.querySelector<HTMLInputElement>("#regimentSize")!.value || 500)));
  setup.settings.terrain = root.querySelector<HTMLSelectElement>("#terrain")!.value as CombatSettings["terrain"];
  setup.settings.crossing = root.querySelector<HTMLSelectElement>("#crossing")!.value as CombatSettings["crossing"];
  for (const side of ["attackers", "defenders"] as const) for (const stat of ["fire", "shock", "maneuver"] as const) {
    const value = +root.querySelector<HTMLInputElement>(`[data-general="${side}"][data-stat="${stat}"]`)!.value || 0;
    setup.settings.generals[side][stat] = Math.max(0, Math.min(6, Math.round(value)));
  }

  root.querySelectorAll<HTMLTableRowElement>("#unitRows tr").forEach(row => {
    const unit = setup.units.find(candidate => candidate.id === row.dataset.unit)!;
    unit.name = row.querySelector<HTMLInputElement>(".unit-name")!.value.trim() || "Unnamed unit";
    unit.color = row.querySelector<HTMLInputElement>(".unit-color")!.value;
    unit.baseMorale = Math.max(1, Math.min(300, +row.querySelector<HTMLInputElement>(".unit-morale")!.value || 100));
    unit.power = Math.max(0, +row.querySelector<HTMLInputElement>(".unit-power")!.value || 0);
    unit.flankingRange = readPips(row, ".unit-flanking");
    unit.fireAttack = readPips(row, ".fire-attack");
    unit.fireDefense = readPips(row, ".fire-defense");
    unit.shockAttack = readPips(row, ".shock-attack");
    unit.shockDefense = readPips(row, ".shock-defense");
    unit.moraleAttack = readPips(row, ".morale-attack");
    unit.moraleDefense = readPips(row, ".morale-defense");
  });

  for (const side of ["attackers", "defenders"] as const) {
    const armyName = root.querySelector<HTMLInputElement>(`[data-army="${side}"]`)!.value.trim();
    setup.armies[side].name = armyName || (side === "attackers" ? "Attackers" : "Defenders");
    for (const unit of setup.units) {
      setup.armies[side].counts[unit.id] = Math.max(0, Math.floor(+root.querySelector<HTMLInputElement>(`[data-count="${unit.id}"]`)!.value || 0));
      setup.armies[side].organization[unit.id] = Math.max(0, Math.min(100, +root.querySelector<HTMLInputElement>(`[data-org="${unit.id}"]`)!.value || 0));
    }
  }
}

function readPips(row: HTMLTableRowElement, selector: string): number {
  const value = +row.querySelector<HTMLInputElement>(selector)!.value || 0;
  return Math.max(0, Math.min(6, Math.round(value)));
}

function defaultColor(role: CombatRole): string {
  return role === "flanker" ? "#b18d4f" : role === "backline" ? "#6686a2" : "#71866d";
}

function getArmy(side: SideKey): Army {
  const regiments: Army["regiments"] = [];
  for (const unit of setup.units) {
    let remaining = setup.armies[side].counts[unit.id] || 0;
    let brigade = 1;
    while (remaining > 0) {
      const count = Math.min(setup.settings.regimentSize, remaining);
      regiments.push({
        id: `${unit.id}-${brigade++}`,
        unitId: unit.id,
        count,
        organization: setup.armies[side].organization[unit.id] ?? 100,
        morale: unit.baseMorale
      });
      remaining -= count;
    }
  }

  const formation: FormationPlan = {front: Array(setup.settings.width).fill(null), back: Array(setup.settings.width).fill(null), reserves: []};
  const frontline = regiments.filter(r => setup.units.find(u => u.id === r.unitId)?.role !== "backline");
  const backline = regiments.filter(r => setup.units.find(u => u.id === r.unitId)?.role === "backline");
  const width = setup.settings.width;
  const occupied = frontline.slice(0, width);
  const start = Math.floor((width - occupied.length) / 2);
  const bandSlots = Array.from({length: occupied.length}, (_, i) => start + i);
  const cavalry = occupied.filter(r => setup.units.find(u => u.id === r.unitId)?.role === "flanker");
  const infantry = occupied.filter(r => setup.units.find(u => u.id === r.unitId)?.role !== "flanker");
  const flankSlots = bandSlots.flatMap((_, i) => i === 0 ? [bandSlots[0], bandSlots.at(-1)!] : [bandSlots[i], bandSlots[bandSlots.length - 1 - i]]).filter((slot, i, all) => all.indexOf(slot) === i);
  for (const regiment of cavalry) {
    const slot = flankSlots.find(index => !formation.front[index]) ?? bandSlots.find(index => !formation.front[index]);
    if (slot === undefined) formation.reserves.push(regiment.id); else formation.front[slot] = regiment.id;
  }
  const centerOrder = [...bandSlots].sort((a, b) => Math.abs(a - (width - 1) / 2) - Math.abs(b - (width - 1) / 2));
  for (const regiment of infantry) {
    const slot = centerOrder.find(index => !formation.front[index]);
    if (slot === undefined) formation.reserves.push(regiment.id); else formation.front[slot] = regiment.id;
  }
  formation.reserves.push(...frontline.slice(width).map(r => r.id));
  const centerOut = Array.from({length: width}, (_, i) => i).sort((a, b) => Math.abs(a - (width - 1) / 2) - Math.abs(b - (width - 1) / 2));
  const backOrder = [...formation.front.map((id, i) => id ? i : -1).filter(i => i >= 0), ...centerOut];
  for (const regiment of backline) {
    const slot = backOrder.find(index => !formation.back[index]);
    if (slot === undefined) formation.reserves.push(regiment.id); else formation.back[slot] = regiment.id;
  }
  const saved = setup.armies[side].formation;
  if (saved) {
    const savedIds = [...saved.front, ...saved.back, ...saved.reserves].filter((id): id is string => Boolean(id));
    const regimentIds = new Set(regiments.map(regiment => regiment.id));
    if (savedIds.length === regimentIds.size && new Set(savedIds).size === savedIds.length && savedIds.every(id => regimentIds.has(id))) {
      return {name: setup.armies[side].name, regiments, formation: structuredClone(saved)};
    }
  }
  return {name: setup.armies[side].name, regiments, formation};
}

function prepareBattle(): void {
  setBattleInputsDisabled(false);
  activeBattle = null;
  readControls();
  preparedArmies = {attackers: getArmy("attackers"), defenders: getArmy("defenders")};
  for (const side of ["attackers", "defenders"] as const)
    setup.armies[side].formation = structuredClone(preparedArmies[side].formation!);
  renderDeployment();
  root.querySelector<HTMLElement>("#deployment")!.hidden = false;
  const startButton = root.querySelector<HTMLButtonElement>("#startBattle")!;
  startButton.hidden = false;
  root.querySelector<HTMLButtonElement>("#resolveUntilSurrender")!.hidden = false;
  startButton.textContent = "Resolve first round";
  root.querySelector<HTMLElement>("#results")!.innerHTML = "";
  root.querySelector<HTMLElement>("#deployment")!.scrollIntoView({behavior: "smooth", block: "start"});
}

function renderDeployment(): void {
  if (!preparedArmies) return;
  const host = root.querySelector<HTMLElement>("#deploymentArmies")!;
  const renderSide = (side: SideKey, color: string) => {
    const army = preparedArmies![side];
    const plan = army.formation!;
    const regimentById = new Map(army.regiments.map(regiment => [regiment.id, regiment]));
    const unitById = new Map(setup.units.map(unit => [unit.id, unit]));
    const card = (id: string) => {
      const regiment = regimentById.get(id)!;
      const unit = unitById.get(regiment.unitId)!;
      const selected = selectedBrigade?.side === side && selectedBrigade.id === id;
      const retired = Boolean(regiment.retreated);
      const status = retired ? "Retreated" : `${Math.round(regiment.morale)} morale`;
      return `<div class="brigade-card ${retired ? "retreated" : ""} ${selected ? "selected" : ""}" style="--unit-color:${unit.color || defaultColor(unit.role)}" ${retired ? "" : `draggable="true" data-brigade="${escapeHtml(id)}" data-side="${side}"`} title="${retired ? "Cannot return to this battle" : "Drag to a rank, or select this brigade and tap a slot"}"><b>${escapeHtml(unit.name)}</b><span>${regiment.count} troops</span><small>${status} · ${Math.round(regiment.organization)}% org</small></div>`;
    };
    const renderRow = (band: "front" | "back", label: string) => {
      const ids = plan[band];
      const slots = Array.from({length: setup.settings.width}, (_, index) => {
      const id = ids[index] || null;
        return `<div class="drop-slot ${id ? "occupied" : ""}" data-side="${side}" data-band="${band}" data-index="${index}">${id ? card(id) : `<span>Drop brigade</span>`}</div>`;
      }).join("");
      return `<div class="deployment-row"><span class="deployment-label">${label}</span><div class="deployment-grid" style="--width:${setup.settings.width}">${slots}</div></div>`;
    };
    const retired = army.regiments.filter(regiment => regiment.retreated).map(regiment => regiment.id);
    return `<section class="deployment-side ${color}"><h3>${escapeHtml(army.name)}</h3>${renderRow("back", "Backline")}<div class="deployment-divider">FACING ENEMY</div>${renderRow("front", "Frontline")}<div class="reserve-tray" data-side="${side}" data-band="reserves" title="Reserves lose 6% of maximum morale per phase. Maneuver increases the number that can reinforce the line each phase."><b>Reserves</b><div>${plan.reserves.map(card).join("") || `<span class="reserve-empty">No ready reserves</span>`}</div></div>${retired.length ? `<div class="reserve-tray retired-tray"><b>Retreated</b><div>${retired.map(card).join("")}</div></div>` : ""}</section>`;
  };

  host.innerHTML = renderSide("attackers", "red") + renderSide("defenders", "blue");
  host.querySelectorAll<HTMLElement>("[data-brigade]").forEach(element => {
    element.addEventListener("dragstart", event => {
      selectedBrigade = {side: element.dataset.side as SideKey, id: element.dataset.brigade!};
      (event as DragEvent).dataTransfer?.setData("text/plain", `${element.dataset.side}|${element.dataset.brigade}`);
    });
    element.addEventListener("dragend", () => {
      selectedBrigade = null;
    });
  });
  host.querySelectorAll<HTMLElement>(".drop-slot, .reserve-tray").forEach(target => {
    target.addEventListener("dragover", event => event.preventDefault());
    target.addEventListener("drop", event => {
      event.preventDefault();
      const transfer = (event as DragEvent).dataTransfer?.getData("text/plain").split("|");
      const side = target.dataset.side as SideKey;
      const id = transfer?.[1];
      if (transfer?.[0] !== side || !id) return;
      moveBrigade(side, id, target.dataset.band as "front" | "back" | "reserves", +(target.dataset.index || 0));
    });
    target.addEventListener("click", event => {
      const brigade = (event.target as HTMLElement).closest<HTMLElement>("[data-brigade]");
      if (brigade) {
        selectedBrigade = {side: brigade.dataset.side as SideKey, id: brigade.dataset.brigade!};
        renderDeployment();
        return;
      }
      if (!selectedBrigade || selectedBrigade.side !== target.dataset.side) return;
      moveBrigade(selectedBrigade.side, selectedBrigade.id, target.dataset.band as "front" | "back" | "reserves", +(target.dataset.index || 0));
    });
  });
  root.querySelector<HTMLButtonElement>("#startBattle")!.onclick = runBattle;
}

function moveBrigade(side: SideKey, id: string, band: "front" | "back" | "reserves", index: number): void {
  const formation = preparedArmies?.[side].formation;
  if (!formation) return;
  if (preparedArmies?.[side].regiments.find(regiment => regiment.id === id)?.retreated) return;
  const target = formation[band];
  const displaced = band === "reserves" ? undefined : target[index];
  for (const row of [formation.front, formation.back]) {
    const currentIndex = row.indexOf(id);
    if (currentIndex >= 0) row[currentIndex] = null;
  }
  const reserveIndex = formation.reserves.indexOf(id);
  if (reserveIndex >= 0) formation.reserves.splice(reserveIndex, 1);
  if (displaced && displaced !== id) {
    for (const row of [formation.front, formation.back]) {
      const currentIndex = row.indexOf(displaced);
      if (currentIndex >= 0) row[currentIndex] = null;
    }
    const reserveDisplaced = formation.reserves.indexOf(displaced);
    if (reserveDisplaced >= 0) formation.reserves.splice(reserveDisplaced, 1);
    formation.reserves.push(displaced);
  }
  if (band === "reserves") target.push(id);
  else target[index] = id;
  setup.armies[side].formation = structuredClone(formation);
  selectedBrigade = null;
  root.querySelector<HTMLElement>("#deployHelp")!.textContent = `Each block holds at most ${setup.settings.regimentSize} troops. Infantry starts near the center and cavalry on the flanks; you can rearrange units between rounds.`;
  renderDeployment();
}

function runBattle(): void {
  if (!preparedArmies) {
    prepareBattle();
    return;
  }
  if (!activeBattle) {
    activeBattle = startBattle(preparedArmies.attackers, preparedArmies.defenders, setup.units, setup.settings);
    preparedArmies = {attackers: activeBattle.attackers, defenders: activeBattle.defenders};
    setBattleInputsDisabled(true);
    root.querySelector<HTMLButtonElement>("#startBattle")!.hidden = true;
    root.querySelector<HTMLButtonElement>("#resolveUntilSurrender")!.hidden = true;
  }
  resolveNextRound(activeBattle, setup.units, setup.settings);
  preparedArmies = {attackers: activeBattle.attackers, defenders: activeBattle.defenders};
  renderDeployment();
  renderBattleProgress();
}

function runUntilSurrender(): void {
  if (!preparedArmies) return;
  if (!activeBattle) {
    activeBattle = startBattle(preparedArmies.attackers, preparedArmies.defenders, setup.units, setup.settings);
    preparedArmies = {attackers: activeBattle.attackers, defenders: activeBattle.defenders};
    setBattleInputsDisabled(true);
  }
  root.querySelector<HTMLButtonElement>("#startBattle")!.hidden = true;
  root.querySelector<HTMLButtonElement>("#resolveUntilSurrender")!.hidden = true;
  while (!activeBattle.done) resolveNextRound(activeBattle, setup.units, setup.settings);
  preparedArmies = {attackers: activeBattle.attackers, defenders: activeBattle.defenders};
  renderDeployment();
  renderBattleProgress();
}

function setBattleInputsDisabled(disabled: boolean): void {
  root.querySelectorAll<HTMLInputElement | HTMLSelectElement>(".settings input, .command-card input, .command-card select, #regimentSize, #unitRows input, #unitRows select, .armies input").forEach(input => {
    input.disabled = disabled;
  });
  root.querySelector<HTMLButtonElement>("#prepareBattle")!.disabled = disabled;
}

function renderBattleProgress(): void {
  const battle = activeBattle!;
  const heading = battle.winner ? `${escapeHtml(battle.winner)} wins` : battle.done ? "No clear winner" : "Battle in progress";
  const status = battle.done ? battle.reason : `Round ${battle.rounds.length} resolved. Click to advance one round.`;
  const action = battle.done
    ? embedded ? `<button id="applyBattleResult" class="primary">Apply result to map</button>` : `<button id="prepareAnother" class="quiet">Prepare another battle</button>`
    : `<button id="adjustFormation" class="quiet">Adjust formation</button> <button id="advanceRound" class="primary">Resolve next round</button> <button id="resolveUntilSurrender" class="quiet" title="Automatically resolve rounds until one army breaks or is destroyed.">Resolve battle</button>${embedded ? ` <button id="applyBattleResult" class="quiet">End battle and apply current losses</button>` : ""}`;
  const summary = `<div class="result-summary"><span class="eyebrow">${battle.done ? "BATTLE RESULT" : "CURRENT BATTLE"}</span><h2>${heading}</h2><p>${escapeHtml(status)} · ${battle.rounds.length} rounds</p>${action}</div>`;
  const total = (army: Army) => army.regiments.filter(regiment => !regiment.retreated).reduce((sum, regiment) => sum + regiment.count, 0);
  const casualties = (side: "attackers" | "defenders") => battle.rounds.reduce((sum, round) => sum + (side === "attackers" ? round.attackerLosses : round.defenderLosses), 0);
  const retreats = (army: Army) => army.regiments.filter(regiment => regiment.retreated && regiment.count > 0).length;
  const totals = `<div class="totals battle-summary"><span>${escapeHtml(battle.attackers.name)} · <b>${total(battle.attackers).toLocaleString()}</b> troops remain · ${casualties("attackers").toLocaleString()} casualties · ${retreats(battle.attackers)} regiments retreated · ${Math.round(battle.attackerMorale)}% morale</span><span>${escapeHtml(battle.defenders.name)} · <b>${total(battle.defenders).toLocaleString()}</b> troops remain · ${casualties("defenders").toLocaleString()} casualties · ${retreats(battle.defenders)} regiments retreated · ${Math.round(battle.defenderMorale)}% morale</span></div>`;
  const rounds = battle.rounds.map(round => renderRound(round)).join("");
  const results = root.querySelector<HTMLElement>("#results")!;
  results.innerHTML = `${summary}${totals}${rounds}`;
  const history = results.querySelectorAll<HTMLDetailsElement>(".round-card");
  history.forEach(card => (card.open = false));
  if (history.length) history[history.length - 1].open = true;
  results.querySelector<HTMLButtonElement>("#advanceRound")?.addEventListener("click", runBattle);
  results.querySelector<HTMLButtonElement>("#resolveUntilSurrender")?.addEventListener("click", runUntilSurrender);
  results.querySelector<HTMLButtonElement>("#adjustFormation")?.addEventListener("click", () => root.querySelector<HTMLElement>("#deployment")!.scrollIntoView({behavior: "smooth", block: "center"}));
  results.querySelector<HTMLButtonElement>("#prepareAnother")?.addEventListener("click", prepareBattle);
  results.querySelector<HTMLButtonElement>("#applyBattleResult")?.addEventListener("click", sendEmbeddedResult);
  results.scrollIntoView({behavior: "smooth", block: "start"});
}

function sendEmbeddedResult(): void {
  if (!embedded || !preparedArmies) return;
  const counts = {attackers: Object.fromEntries(setup.units.map(unit => [unit.id, 0])), defenders: Object.fromEntries(setup.units.map(unit => [unit.id, 0]))};
  for (const side of ["attackers", "defenders"] as const) {
    const army = activeBattle?.[side] ?? preparedArmies[side];
    for (const regiment of army.regiments) {
      if (!regiment.retreated) counts[side][regiment.unitId] = (counts[side][regiment.unitId] ?? 0) + regiment.count;
    }
  }
  window.parent.postMessage({type: "azgaar-combat-result", counts}, postTarget);
}
function renderRound(round: RoundResult): string {
  const formation = (title: string, army: Formation, mirrored: boolean, die: number) => {
    const slots = (items: FormationSlot[]) => {
      const cells = Array.from({length: setup.settings.width}, () => `<div class="grid-slot empty" aria-hidden="true"></div>`);
      for (const item of items) if (item.column >= 0 && item.column < cells.length) cells[item.column] = renderSlot(item, round.phase);
      return (mirrored ? cells.reverse() : cells).join("");
    };
    const reserve = army.reserves.length
      ? `<div class="reserve-line"><span>Reserve</span><div class="reserve-slots">${army.reserves.map(item => renderSlot(item, round.phase)).join("")}</div></div>`
      : "";
    return `<section class="formation-side ${mirrored ? "defending-side" : "attacking-side"}">
      <h3><span>${title}</span><span class="dice-corner" title="This side's ten-sided die roll"><small>D10</small><b>${die}</b></span></h3>
      <div class="rank-label">Back rank</div><div class="combat-rank" style="--width:${setup.settings.width}">${slots(army.back)}</div>
      <div class="battle-center"><span class="phase ${round.phase}">${round.phase}</span><i></i></div>
      <div class="combat-rank frontline-rank" style="--width:${setup.settings.width}">${slots(army.front)}</div><div class="rank-label">Front rank</div>
      ${reserve}
    </section>`;
  };
  return `<details class="round-card"><summary>Round ${round.round} · <span class="phase ${round.phase}">${round.phase}</span> · dice ${round.attackerDie}–${round.defenderDie} · losses ${round.attackerLosses}–${round.defenderLosses}</summary><div class="battle-grid">${formation(`Attackers · ${Math.round(round.attackerPower)} power · ${Math.round(round.attackerMorale)} morale`, round.attackerFormation, false, round.attackerDie)}${formation(`Defenders · ${Math.round(round.defenderPower)} power · ${Math.round(round.defenderMorale)} morale`, round.defenderFormation, true, round.defenderDie)}</div></details>`;
}

function renderSlot(slot: FormationSlot, phase: "fire" | "shock"): string {
  const unit = setup.units.find(candidate => candidate.id === slot.unitId);
  const attack = unit ? (phase === "fire" ? unit.fireAttack : unit.shockAttack) : 0;
  const defense = unit ? (phase === "fire" ? unit.fireDefense : unit.shockDefense) : 0;
  const moraleAttack = unit?.moraleAttack ?? 0;
  const moraleDefense = unit?.moraleDefense ?? 0;
  const initials = slot.name.split(/\s+/).map(part => part[0]).join("").slice(0, 2).toUpperCase();
  const exposed = slot.row === "front" && slot.role === "backline" ? slot.unitId === "artillery" ? " | Exposed: -2 attack roll, half strength, takes 2x casualties" : " | Exposed: -1 attack roll, 75% strength, takes 1.25x casualties" : "";
  const tooltip = `${slot.name} | ${slot.count.toLocaleString()} troops | Morale ${Math.round(slot.morale)}/${Math.round(slot.moraleMax)} | ${Math.round(slot.organization)}% organization | ${phase} attack ${attack}, defense ${defense} | morale attack ${moraleAttack}, defense ${moraleDefense}${exposed}`;
  return `<div class="grid-slot" style="--unit-color:${slot.color || defaultColor(slot.role)}" title="${escapeHtml(tooltip)}"><b>${escapeHtml(initials)}</b><span>${slot.count}</span><i style="--morale:${Math.round(slot.morale / Math.max(1, slot.moraleMax) * 100)}%"></i><small>${phase.toUpperCase()} A${attack} D${defense} M${moraleAttack}/${moraleDefense}</small></div>`;
}

function exportSetup(): void {
  readControls();
  const blob = new Blob([JSON.stringify(setup, null, 2)], {type: "application/json"});
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "combat-simulator-land-setup.json";
  link.click();
  URL.revokeObjectURL(url);
}

async function importSetup(event: Event): Promise<void> {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;
  try {
    const incoming = JSON.parse(await file.text()) as Setup;
    if (!Array.isArray(incoming.units) || !incoming.settings || !incoming.armies?.attackers || !incoming.armies?.defenders)
      throw new Error("The file does not contain a combat sandbox setup.");
    incoming.settings.regimentSize = Math.max(1, Math.min(10000, Math.floor(incoming.settings.regimentSize || 500)));
    incoming.settings.terrain ||= "plains";
    incoming.settings.crossing ||= "none";
    incoming.settings.generals ||= {attackers: {fire: 0, shock: 0, maneuver: 0}, defenders: {fire: 0, shock: 0, maneuver: 0}};
    for (const side of ["attackers", "defenders"] as const) incoming.settings.generals[side] ||= {fire: 0, shock: 0, maneuver: 0};
    incoming.units.forEach(unit => {
      unit.baseMorale = Math.max(1, Math.min(300, +unit.baseMorale || 100));
      unit.color ||= defaultColor(unit.role);
      unit.flankingRange ??= unit.role === "flanker" ? 2 : 1;
      unit.moraleAttack ??= 1;
      unit.moraleDefense ??= 1;
    });
    setup = incoming;
    render();
  } catch (error) {
    alert(error instanceof Error ? error.message : "Could not read this setup file.");
  }
}

window.addEventListener("message", event => {
  if (!embedded || event.source !== window.parent || (postTarget !== "*" && event.origin !== location.origin)) return;
  if (event.data?.type === "azgaar-combat-setup" && event.data.mode === "land") {
    setup = event.data.setup as Setup;
    preparedArmies = null; activeBattle = null; selectedBrigade = null;
    render();
  } else if (event.data?.type === "azgaar-combat-setup" && event.data.mode === "naval") {
    renderNaval(root, render, event.data.setup, sendEmbeddedNavalResult);
  }
});

function sendEmbeddedNavalResult(counts: Record<"attackers" | "defenders", Record<string, number>>): void {
  if (embedded) window.parent.postMessage({type: "azgaar-combat-result", counts}, postTarget);
}

root.addEventListener("input", event => {
  const target = event.target as HTMLElement;
  if (!preparedArmies || target.closest("#deployment")) return;
  preparedArmies = null;
  selectedBrigade = null;
  delete setup.armies.attackers.formation;
  delete setup.armies.defenders.formation;
  root.querySelector<HTMLElement>("#deployment")!.hidden = true;
});

render();
